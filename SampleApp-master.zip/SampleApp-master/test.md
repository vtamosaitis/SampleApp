this is a test to see if git is linked to github

testing merge

testing pull request

testing detailed commit message