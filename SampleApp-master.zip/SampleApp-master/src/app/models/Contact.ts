export class Contact {
    constructor(
        public id: String,
        public name: String,
        public phoneNumber: String
    ) {}

  }