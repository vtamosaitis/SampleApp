const CONSTANTS = {
    TABLENAME: "Contacts",
    REGION: "us-west-1",
    ENDPOINT: "http://localhost:8000",
    ACCESSKEYID: 'xxxx',
    SECRETACCESSKEY: 'xxxx'
}

module.exports = { CONSTANTS };